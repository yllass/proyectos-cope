/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package errores;

/**
 *
 * Esther Alicia Félix Gil
 * 12 de septiembre de 2025
 * Calculadora de Errores Numéricos: Aplicación en Java que calcula 
 * y muestra el error absoluto y relativo entre un valor real y 
 * uno aproximado, con una interfaz gráfica sencilla e intuitiva
 */
public class CalculadoraErrores {
    

    public static double calcularErrorAbsoluto(double real, double aprox) {
        return Math.abs(real - aprox);
    }

    public static double calcularErrorRelativo(double real, double aprox) {
        if (real == 0) throw new ArithmeticException("El valor real no puede ser cero");
        return calcularErrorAbsoluto(real, aprox) / Math.abs(real);
    }
    
}
