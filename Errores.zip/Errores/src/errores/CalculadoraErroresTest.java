/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package errores;

public class CalculadoraErroresTest {

    public static void main(String[] args) {
        double valorReal = 12;
        double valorAprox = 15;

        double errorAbs = CalculadoraErrores.calcularErrorAbsoluto(valorReal, valorAprox);
        double errorRel = CalculadoraErrores.calcularErrorRelativo(valorReal, valorAprox);

        System.out.println("Valor real: " + valorReal);
        System.out.println("Valor aproximado: " + valorAprox);
        System.out.println("Error absoluto: " + errorAbs);
        System.out.println("Error relativo: " + (errorRel * 100) + " %");

        // Puedes agregar más casos de prueba
        testError(100, 105, 5, 0.05);
        testError(50, 45, 5, 0.1);
    }

    private static void testError(double real, double aprox, double esperadoAbs, double esperadoRel) {
        double abs = CalculadoraErrores.calcularErrorAbsoluto(real, aprox);
        double rel = CalculadoraErrores.calcularErrorRelativo(real, aprox);
        if (abs == esperadoAbs && rel == esperadoRel) {
            System.out.println("Prueba correcta para valores: " + real + " y " + aprox);
        } else {
            System.out.println("Prueba fallida para valores: " + real + " y " + aprox);
        }
    }
}
