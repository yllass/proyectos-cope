/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pruebas;

import implementaciones.RaicesFunciones;
import java.util.function.DoubleUnaryOperator;
import javax.swing.table.DefaultTableModel;
/**
 * PruebaRaicesFunciones.java
 * Autor: Esther Alicia Félix Gil        ID: 00000252369
 * Fecha de creación: 21/09/2025
 *
 * Descripción:
 * Clase de pruebas para validar los métodos numéricos implementados en
 * RaicesFunciones. Permite ejecutar ejemplos de las funciones f(x) y g(x)
 * utilizando los métodos de Bisección y Regla Falsa.
 *
 * Funciones de prueba:
 *  - f(x) = 4x³ - 6x² + 7x - 2.3
 *  - g(x) = x * |cos(x)| - 5
 *
 * Métodos utilizados:
 *  - biseccion(f, Xi, Xf, iterMax, modelo)
 *  - reglaFalsa(f, Xi, Xf, iterMax, modelo)
 *
 * Características:
 *  - Usa un DefaultTableModel para almacenar los resultados de las iteraciones.
 *  - Imprime los resultados en consola en forma tabular.
 *  - Iteraciones máximas establecidas en 10 para este ejemplo.
 *
 * Comentarios:
 *  - Este archivo sirve como punto de entrada para validar la librería
 *    RaicesFunciones, mostrando en consola paso a paso la convergencia de los
 *    métodos.
 *  - Se puede modificar la cantidad de iteraciones o la función bajo análisis
 *    para hacer más pruebas.
 */
public class PruebaRaicesFunciones {
    public static void main(String[] args) {
        RaicesFunciones solver = new RaicesFunciones();

        DoubleUnaryOperator f = (x) -> 4.0*Math.pow(x,3) - 6.0*Math.pow(x,2) + 7.0*x - 2.3;
        DoubleUnaryOperator g = (x) -> x*Math.abs(Math.cos(x)) - 5.0;

        int iterMax = 10; // por ejemplo, 10 iteraciones

        DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{"i","Xi","Xf","Xr","f(Xi)","f(Xf)","f(Xr)","ea%"}, 0
        );

        System.out.println("Bisección:");
        solver.biseccion(f, 0.0, 1.0, iterMax, modelo);

        // Imprimir resultados en consola
        for(int i=0; i<modelo.getRowCount(); i++){
            for(int j=0; j<modelo.getColumnCount(); j++){
                System.out.print(modelo.getValueAt(i,j) + "\t");
            }
            System.out.println();
        }

        System.out.println("\nRegla Falsa:");
        modelo.setRowCount(0); // limpiar
        solver.reglaFalsa(g, 2.0, 3.0, iterMax, modelo);

        for(int i=0; i<modelo.getRowCount(); i++){
            for(int j=0; j<modelo.getColumnCount(); j++){
                System.out.print(modelo.getValueAt(i,j) + "\t");
            }
            System.out.println();
        }
    }
}