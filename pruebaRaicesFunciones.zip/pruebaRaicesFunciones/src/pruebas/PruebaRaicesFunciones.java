/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pruebas;

import implementaciones.RaicesFunciones;
import java.util.function.DoubleUnaryOperator;
import javax.swing.table.DefaultTableModel;
/**
 * Clase de prueba para validar el funcionamiento de los métodos numéricos
 * de la clase {@link implementaciones.RaicesFunciones}.
 * 
 * Esta clase ejecuta ejemplos prácticos de los métodos:
 * Ambos métodos se utilizan para encontrar raíces de funciones en un intervalo
 * dado. Los resultados se almacenan en un {@link DefaultTableModel} y se
 * imprimen en consola.
 * 
 * @author Infraestructura
 */
public class PruebaRaicesFunciones {
    public static void main(String[] args) {
         // Crear instancia de la clase que implementa los métodos de raíces
        RaicesFunciones solver = new RaicesFunciones();
         // Definir funciones a evaluar usando expresiones lambda
        DoubleUnaryOperator f = (x) -> 4.0*Math.pow(x,3) - 6.0*Math.pow(x,2) + 7.0*x - 2.3;
        DoubleUnaryOperator g = (x) -> x*Math.abs(Math.cos(x)) - 5.0;
         // Número máximo de iteraciones permitido
        int iterMax = 10; // por ejemplo, 10 iteraciones
        // Modelo de tabla para almacenar resultados de iteraciones
        DefaultTableModel modelo = new DefaultTableModel(
            new Object[]{"i","Xi","Xf","Xr","f(Xi)","f(Xf)","f(Xr)","ea%"}, 0
        );
         // ---------------- PRUEBA DE MÉTODO DE BISECCIÓN ----------------
        System.out.println("Bisección:");
        solver.biseccion(f, 0.0, 1.0, iterMax, modelo);

        // Imprimir resultados en consola
        for(int i=0; i<modelo.getRowCount(); i++){
            for(int j=0; j<modelo.getColumnCount(); j++){
                System.out.print(modelo.getValueAt(i,j) + "\t");
            }
            System.out.println();
        }
        // ---------------- PRUEBA DE MÉTODO DE REGLA FALSA ----------------
        System.out.println("\nRegla Falsa:");
        modelo.setRowCount(0); // limpiar
        solver.reglaFalsa(g, 2.0, 3.0, iterMax, modelo);
        // Imprimir resultados en consola
        for(int i=0; i<modelo.getRowCount(); i++){
            for(int j=0; j<modelo.getColumnCount(); j++){
                System.out.print(modelo.getValueAt(i,j) + "\t");
            }
            System.out.println();
        }
    }
}