 /*Click nbfs://nbhost/SystemFileSystem/templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pruebas;

import implementaciones.RaicesFunciones;
import java.util.function.DoubleUnaryOperator;

/**
 * PruebaRaicesFunciones.java
 * Autor: Zamudio Corona Javier Sabdiel  ID: 00000251925
 * Fecha de creación: 16/09/2025
 *
 * Programa principal que realiza las pruebas solicitadas en la asignación 04:
 *  - Bisección (función f)
 *  - Regla Falsa (función g)
 *  - Newton-Raphson (f con df)
 *  - Secante (g)
 *
 * Salida:
 *  - Se muestran mensajes descriptivos previos y posteriores a cada cálculo.
 *  - Los resultados se presentan con un formato de 6 cifras decimales.
 *  - Se incluyen saltos de línea adicionales para facilitar la lectura.
 */
public class PruebaRaicesFunciones {

    /**
     * Método principal.
     *
     * @param args argumentos de línea de comando (no usados)
     */
    public static void main(String[] args) {
        RaicesFunciones solver = new RaicesFunciones();

        /* Definición de funciones con expresiones lambda */
        DoubleUnaryOperator f = (x) -> 4.0 * Math.pow(x, 3)
                                      - 6.0 * Math.pow(x, 2)
                                      + 7.0 * x
                                      - 2.3;

        DoubleUnaryOperator df = (x) -> 12.0 * Math.pow(x, 2)
                                       - 12.0 * x
                                       + 7.0;

        DoubleUnaryOperator g = (x) -> x * Math.abs(Math.cos(x))
                                      - 5.0;

        /* Parámetro de tolerancia */
        double eamax = 0.0001;

        /* -------------------------
           Método de Bisección (f)
           Intervalo: [0.0, 1.0]
           ------------------------- */
        System.out.println("Método de Bisección (función f)");
        System.out.println("Descripción: Se busca una raíz de f(x) = 4x^3 - 6x^2 + 7x - 2.3");
        System.out.println("Intervalo: [0.0, 1.0], Error máximo permitido: " + eamax);
        System.out.println();

        try {
            double raizB = solver.biseccion(f, 0.0, 1.0, eamax);
            double valorFuncion = f.applyAsDouble(raizB);
            int iterB = solver.getIteraciones();

            System.out.printf("Raíz (bisección)     : %.6f%n", raizB);
            System.out.printf("f(raíz)              : %.6f%n", valorFuncion);
            System.out.printf("Iteraciones          : %d%n", iterB);
        } catch (Exception ex) {
            System.out.println("Error en Bisección: " + ex.getMessage());
        }

        System.out.println("\n----------------------------------------\n");

        /* -------------------------
           Regla Falsa (g)
           Intervalos: [-3.0, -2.0] y [2.0, 3.0]
           ------------------------- */
        System.out.println("Método de la Regla Falsa (función g)");
        System.out.println("Descripción: Se busca una raíz de g(x) = x * |cos(x)| - 5");
        System.out.println("Intervalos: [-3.0, -2.0] y [2.0, 3.0], Error máximo permitido: " + eamax);
        System.out.println();

        double[] xiVals = {-3.0, 2.0};
        double[] xfVals = {-2.0, 3.0};

        for (int i = 0; i < xiVals.length; i++) {
            double xi = xiVals[i];
            double xf = xfVals[i];

            System.out.printf("Regla Falsa: intervalo [%.1f, %.1f]%n", xi, xf);
            try {
                double raizRF = solver.reglaFalsa(g, xi, xf, eamax);
                double valg = g.applyAsDouble(raizRF);
                int iterRF = solver.getIteraciones();

                System.out.printf("Raíz (regla falsa)   : %.6f%n", raizRF);
                System.out.printf("g(raíz)              : %.6f%n", valg);
                System.out.printf("Iteraciones          : %d%n", iterRF);
            } catch (Exception ex) {
                System.out.println("Error en Regla Falsa: " + ex.getMessage());
            }
            System.out.println();
        }

        System.out.println("\n----------------------------------------\n");

        /* -------------------------
           Newton - Raphson (f, df)
           Valor inicial: 0.0
           ------------------------- */
        System.out.println("Método de Newton - Raphson (función f)");
        System.out.println("Descripción: Se busca una raíz de f(x) = 4x^3 - 6x^2 + 7x - 2.3");
        System.out.println("Valor inicial: 0.0, Error máximo permitido: " + eamax);
        System.out.println();

        try {
            double raizNR = solver.newtonRaphson(f, df, 0.0, eamax);
            double valfNR = f.applyAsDouble(raizNR);
            int iterNR = solver.getIteraciones();

            System.out.printf("Raíz (Newton-Raphson): %.6f%n", raizNR);
            System.out.printf("f(raíz)              : %.6f%n", valfNR);
            System.out.printf("Iteraciones          : %d%n", iterNR);
        } catch (Exception ex) {
            System.out.println("Error en Newton-Raphson: " + ex.getMessage());
        }

        System.out.println("\n----------------------------------------\n");

        /* -------------------------
           Secante (g)
           Intervalos: [-3.0, -2.0] y [2.0, 3.0]
           ------------------------- */
        System.out.println("Método de la Secante (función g)");
        System.out.println("Descripción: Se busca una raíz de g(x) = x * |cos(x)| - 5");
        System.out.println("Intervalos: [-3.0, -2.0] y [2.0, 3.0], Error máximo permitido: " + eamax);
        System.out.println();

        for (int i = 0; i < xiVals.length; i++) {
            double x1 = xiVals[i];
            double x2 = xfVals[i];

            System.out.printf("Secante: puntos iniciales [%.1f, %.1f]%n", x1, x2);
            try {
                double raizSec = solver.secante(g, x1, x2, eamax);
                double valgSec = g.applyAsDouble(raizSec);
                int iterSec = solver.getIteraciones();

                System.out.printf("Raíz (secante)       : %.6f%n", raizSec);
                System.out.printf("g(raíz)              : %.6f%n", valgSec);
                System.out.printf("Iteraciones          : %d%n", iterSec);
            } catch (Exception ex) {
                System.out.println("Error en Secante: " + ex.getMessage());
            }
            System.out.println();
        }

        System.out.println("Fin de las pruebas. Todos los resultados se muestran con 6 decimales.");
    }
}