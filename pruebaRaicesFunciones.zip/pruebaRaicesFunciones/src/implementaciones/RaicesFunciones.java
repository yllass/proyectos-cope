/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package implementaciones;

import java.util.function.DoubleUnaryOperator;

/**
 * RaicesFunciones.java
 * Autor: Zamudio Corona Javier Sabdiel  ID: 00000251925
 * Fecha de creación: 16/09/2025
 *
 * Clase que implementa métodos numéricos para encontrar raíces de funciones:
 *  - Bisección
 *  - Regla falsa (falsa posición)
 *  - Newton - Raphson
 *  - Secante
 *
 * Comentarios:
 *- Cada uno de los métodos recibe como parámetro un objeto de tipo DoubleUnaryOperator,
 *el cual define la función f(x) (y su derivada df en el caso del método de Newton-Raphson).
 *- En el atributo 'iteraciones' se almacena la cantidad de pasos efectuados durante el proceso.
 *- El criterio de finalización corresponde al error aproximado, cuando se cumple que
 *|xr - xr_anterior| <= eamax.
 *- El valor de retorno es un double que indica la raíz aproximada obtenida.
 */
public class RaicesFunciones {

    /* Atributo que almacena el número de iteraciones de la última ejecución */
    private int iteraciones;

    /* Constante: número máximo de iteraciones para evitar bucles infinitos */
    private static final int MAX_ITER = 100000;

    /**
     * Devuelve el número de iteraciones realizadas por el último método ejecutado.
     *
     * @return número de iteraciones
     */
    public int getIteraciones() {
        return iteraciones;
    }

    /**
     * Método de Bisección.
     *
     * @param f     función para la cual se busca la raíz (DoubleUnaryOperator)
     * @param xi    extremo izquierdo del intervalo de búsqueda
     * @param xf    extremo derecho del intervalo de búsqueda
     * @param eamax error aproximado máximo (criterio de parada)
     * @return raíz aproximada encontrada
     *
     * Requisitos: f(xi) y f(xf) deben tener signos opuestos (intercambio de signo).
     */
    public double biseccion(DoubleUnaryOperator f, double xi, double xf, double eamax) {
        double fa = f.applyAsDouble(xi);
        double fb = f.applyAsDouble(xf);
        if (fa == 0.0) {
            iteraciones = 0;
            return xi;
        }
        if (fb == 0.0) {
            iteraciones = 0;
            return xf;
        }
        if (fa * fb > 0.0) {
            throw new IllegalArgumentException("Bisección: f(xi) y f(xf) deben tener signos opuestos.");
        }

        double xr = xi;
        double xrAnterior = xr;
        iteraciones = 0;

        while (true) {
            xrAnterior = xr;
            xr = (xi + xf) / 2.0;
            double fr = f.applyAsDouble(xr);

            iteraciones++;

            if (Math.abs(xr - xrAnterior) <= eamax) {
                break;
            }

            if (fa * fr < 0.0) {
                xf = xr;
                fb = fr;
            } else {
                xi = xr;
                fa = fr;
            }

            if (iteraciones >= MAX_ITER) {
                break;
            }
        }

        return xr;
    }

    /**
     * Método de la Regla Falsa (Falsa posición).
     *
     * @param f     función objetivo
     * @param xi    extremo izquierdo del intervalo
     * @param xf    extremo derecho del intervalo
     * @param eamax error aproximado máximo
     * @return raíz aproximada encontrada
     *
     * Requisitos: f(xi) y f(xf) deben tener signos opuestos.
     */
    public double reglaFalsa(DoubleUnaryOperator f, double xi, double xf, double eamax) {
        double fa = f.applyAsDouble(xi);
        double fb = f.applyAsDouble(xf);
        if (fa == 0.0) {
            iteraciones = 0;
            return xi;
        }
        if (fb == 0.0) {
            iteraciones = 0;
            return xf;
        }
        if (fa * fb > 0.0) {
            throw new IllegalArgumentException("Regla Falsa: f(xi) y f(xf) deben tener signos opuestos.");
        }

        double xr = xi;
        double xrAnterior = xr;
        iteraciones = 0;

        while (true) {
            xrAnterior = xr;
            xr = (xi * fb - xf * fa) / (fb - fa); // fórmula para la regla falsa
            double fr = f.applyAsDouble(xr);

            iteraciones++;

            if (Math.abs(xr - xrAnterior) <= eamax) {
                break;
            }

            if (fa * fr < 0.0) {
                xf = xr;
                fb = fr;
            } else {
                xi = xr;
                fa = fr;
            }

            if (iteraciones >= MAX_ITER) {
                break;
            }
        }

        return xr;
    }

    /**
     * Método de Newton - Raphson.
     *
     * @param f     función objetivo
     * @param df    derivada de la función objetivo
     * @param xi    valor inicial
     * @param eamax error aproximado máximo
     * @return raíz aproximada encontrada
     *
     * Requiere df(x) != 0 durante las iteraciones (se lanza ArithmeticException si df == 0).
     */
    public double newtonRaphson(DoubleUnaryOperator f, DoubleUnaryOperator df, double xi, double eamax) {
        double xr = xi;
        double xrAnterior = xr;
        iteraciones = 0;

        while (true) {
            xrAnterior = xr;
            double fval = f.applyAsDouble(xr);
            double dfval = df.applyAsDouble(xr);
            if (dfval == 0.0) {
                throw new ArithmeticException("Newton-Raphson: derivada cero en x = " + xr);
            }
            xr = xr - fval / dfval;

            iteraciones++;

            if (Math.abs(xr - xrAnterior) <= eamax) {
                break;
            }

            if (iteraciones >= MAX_ITER) {
                break;
            }
        }

        return xr;
    }

    /**
     * Método de la Secante.
     *
     * @param f     función objetivo
     * @param x1    primer punto inicial
     * @param x2    segundo punto inicial
     * @param eamax error aproximado máximo
     * @return raíz aproximada encontrada
     *
     * Requiere que las aproximaciones iniciales no hagan una división por cero en la fórmula.
     */
    public double secante(DoubleUnaryOperator f, double x1, double x2, double eamax) {
        double xprev = x1;
        double xcurr = x2;
        double fprev = f.applyAsDouble(xprev);
        double fcurr = f.applyAsDouble(xcurr);
        iteraciones = 0;

        double xnext = xcurr;

        while (true) {
            if ((fcurr - fprev) == 0.0) {
                throw new ArithmeticException("Secante: división por cero (fcurr - fprev == 0).");
            }

            xnext = xcurr - fcurr * (xcurr - xprev) / (fcurr - fprev);

            iteraciones++;

            if (Math.abs(xnext - xcurr) <= eamax) {
                xcurr = xnext;
                break;
            }

            xprev = xcurr;
            fprev = fcurr;
            xcurr = xnext;
            fcurr = f.applyAsDouble(xcurr);

            if (iteraciones >= MAX_ITER) {
                break;
            }
        }

        return xnext;
    }
}
