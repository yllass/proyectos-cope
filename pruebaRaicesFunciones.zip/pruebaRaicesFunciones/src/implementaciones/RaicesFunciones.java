/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package implementaciones;

import java.util.function.DoubleUnaryOperator;
import javax.swing.table.DefaultTableModel;

/**
 * RaicesFunciones.java
 * Autor: Esther Alicia Félix Gil  ID: 00000252369
 * Fecha de creación: 16/09/2025
 *
 * Clase que implementa métodos numéricos para encontrar raíces de funciones:
 *  - Bisección
 *  - Regla falsa (falsa posición)
 *  - Newton - Raphson
 *  - Secante
 *
 * Comentarios:
 *  - Cada método recibe una instancia de DoubleUnaryOperator que representa la función f(x)
 *    (y df en el caso de Newton-Raphson).
 *  - Cada método guarda en el atributo 'iteraciones' el número de iteraciones realizadas.
 *  - Los métodos usan como criterio de parada el error aproximado |xr - xr_anterior| <= eamax.
 *  - Formato de retorno: double que representa la raíz aproximada encontrada.
 */
public class RaicesFunciones {

    // Método de Bisección con tolerancia
    public void biseccion(DoubleUnaryOperator f, double xi, double xf, double tol, DefaultTableModel modelo) {
        double xr=xi;
        double ea = 100;
        int i = 1;
        
        while(ea > tol) {
            double xrold = xr;
        xr = (xi + xf) / 2.0;
        ea = (i == 1) ? 100 : Math.abs((xr - xrold) / xr) * 100;

        Object[] fila = new Object[]{
            i,
            xi,
            xf,
            xr,
            f.applyAsDouble(xi),
            f.applyAsDouble(xf),
            f.applyAsDouble(xr),
            ea
        };
        modelo.addRow(fila);

        if (f.applyAsDouble(xi) * f.applyAsDouble(xr) < 0) {
            xf = xr;
        } else {
            xi = xr;
        }

        i++;
        }
    }

    // Método de Regla Falsa con tolerancia
    public void reglaFalsa(DoubleUnaryOperator f, double xi, double xf, double tol, DefaultTableModel modelo) {
        double xr = xi;
        double ea = 100;
        int i = 1;

        while(ea > tol) {
            double xrold = xr;
        xr = xf - (f.applyAsDouble(xf) * (xi - xf)) / (f.applyAsDouble(xi) - f.applyAsDouble(xf));
        ea = Math.abs((xr - xrold) / xr) * 100;

        Object[] fila = new Object[]{
            i,
            xi,
            xf,
            xr,
            f.applyAsDouble(xi),
            f.applyAsDouble(xf),
            f.applyAsDouble(xr),
            ea
        };
        modelo.addRow(fila);

        if (f.applyAsDouble(xi) * f.applyAsDouble(xr) < 0) {
            xf = xr;
        } else {
            xi = xr;
        }
        i++;
        }
    }
}
