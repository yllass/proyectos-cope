/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package implementaciones;

import java.util.function.DoubleUnaryOperator;
import javax.swing.table.DefaultTableModel;

/**
 * RaicesFunciones.java
 * Autor: Zamudio Corona Javier Sabdiel  ID: 00000251925
 * Fecha de creación: 21/09/2025
 *
 * Clase que implementa métodos numéricos para encontrar raíces de funciones:
 *  - Bisección
 *  - Regla falsa (falsa posición)
 *  - Newton - Raphson
 *  - Secante
 *
 * Comentarios:
 *  - Cada método recibe una instancia de DoubleUnaryOperator que representa la función f(x)
 *    (y df en el caso de Newton-Raphson).
 *  - Cada método guarda en el atributo 'iteraciones' el número de iteraciones realizadas.
 *  - Los métodos usan como criterio de parada el error aproximado |xr - xr_anterior| <= eamax.
 *  - Formato de retorno: double que representa la raíz aproximada encontrada.
 */
public class RaicesFunciones {
    // Atributos que guardan el número de iteraciones realizadas por cada método
    private int iterBiseccion, iterReglaFalsa, iterNewton, iterSecante;
    /** @return número de iteraciones de Bisección */
    public int getIterBiseccion() { return iterBiseccion; }
    /** @return número de iteraciones de Regla Falsa */
    public int getIterReglaFalsa() { return iterReglaFalsa; }
    /** @return número de iteraciones de Newton-Raphson */
    public int getIterNewton() { return iterNewton; }
    /** @return número de iteraciones de Secante */
    public int getIterSecante() { return iterSecante; }
    
    /**
     * Método de Bisección para encontrar la raíz de una función.
     * 
     * @param f     Función a evaluar (f(x)).
     * @param xi    Extremo inferior del intervalo inicial.
     * @param xf    Extremo superior del intervalo inicial.
     * @param tol   Tolerancia de error aproximado (%).
     * @param modelo Tabla donde se guardan las iteraciones.
     */
    public void biseccion(DoubleUnaryOperator f, double xi, double xf, double tol, DefaultTableModel modelo) {
        double xr=xi;
        double ea = 100;
        int i = 1;
        
        while(ea > tol) {
            double xrold = xr;
            xr = (xi + xf) / 2.0;
            ea = (i == 1) ? 100 : Math.abs((xr - xrold) / xr) * 100;
            // Guardar resultados en la tabla
            Object[] fila = new Object[]{
                i,
                xi,
                xf,
                xr,
                f.applyAsDouble(xi),
                f.applyAsDouble(xf),
                f.applyAsDouble(xr),
                ea
            };
            modelo.addRow(fila);
             // Actualizar intervalo según el signo de f(x)
            if (f.applyAsDouble(xi) * f.applyAsDouble(xr) < 0) {
                xf = xr;
            } else {
                xi = xr;
            }

            i++;
        }
        iterBiseccion = i-1;
    }

    /**
     * Método de Regla Falsa (Falsa Posición).
     * 
     * @param f     Función a evaluar (f(x)).
     * @param xi    Extremo inferior del intervalo inicial.
     * @param xf    Extremo superior del intervalo inicial.
     * @param tol   Tolerancia de error aproximado (%).
     * @param modelo Tabla donde se guardan las iteraciones.
     */
    public void reglaFalsa(DoubleUnaryOperator f, double xi, double xf, double tol, DefaultTableModel modelo) {
        double xr = xi;
        double ea = 100;
        int i = 1;

        while(ea > tol) {
            double xrold = xr;
        // Fórmula de regla falsa    
        xr = xf - (f.applyAsDouble(xf) * (xi - xf)) / (f.applyAsDouble(xi) - f.applyAsDouble(xf));
        ea = Math.abs((xr - xrold) / xr) * 100;
        // Guardar resultados
        Object[] fila = new Object[]{
            i,
            xi,
            xf,
            xr,
            f.applyAsDouble(xi),
            f.applyAsDouble(xf),
            f.applyAsDouble(xr),
            ea
        };
        modelo.addRow(fila);
        // Actualizar intervalo
        if (f.applyAsDouble(xi) * f.applyAsDouble(xr) < 0) {
            xf = xr;
        } else {
            xi = xr;
        }
        i++;
        }
        iterReglaFalsa = i-1;
    }
     /**
     * Método de Newton-Raphson.
     * 
     * @param f     Función a evaluar (f(x)).
     * @param df    Derivada de la función f(x).
     * @param x0    Valor inicial.
     * @param tol   Tolerancia de error aproximado (%).
     * @param modelo Tabla donde se guardan las iteraciones.
     */
    public void newtonRaphson(DoubleUnaryOperator f, DoubleUnaryOperator df, double x0, double tol, DefaultTableModel modelo) {
        double x = x0;
        double ea = 100;
        int i = 1;

        while (ea > tol) {
            double xOld = x;
            double dfx = df.applyAsDouble(x);
            if (dfx == 0) break;// Evitar división por cero
            x = x - f.applyAsDouble(x)/dfx;// Fórmula Newton-Raphson
            ea = (i == 1) ? 100 : Math.abs((x - xOld)/x) * 100;
            // Guardar resultados
            modelo.addRow(new Object[]{i, xOld, "-", x, f.applyAsDouble(xOld), "-", f.applyAsDouble(x), ea});
            i++;
        }
        iterNewton = i-1;
    }
     /**
     * Método de la Secante.
     * 
     * @param f     Función a evaluar (f(x)).
     * @param x0    Primer valor inicial.
     * @param x1    Segundo valor inicial.
     * @param tol   Tolerancia de error aproximado (%).
     * @param modelo Tabla donde se guardan las iteraciones.
     */
    public void secante(DoubleUnaryOperator f, double x0, double x1, double tol, DefaultTableModel modelo) {
        double x2 = x1;
        double ea = 100;
        int i = 1;

        while (ea > tol) {
            double fx0 = f.applyAsDouble(x0);
            double fx1 = f.applyAsDouble(x1);
            if (fx1 - fx0 == 0) break;// Evitar división por cero

            double xOld = x2;
            x2 = x1 - fx1*(x1 - x0)/(fx1 - fx0);// Fórmula Secante
            ea = (i == 1) ? 100 : Math.abs((x2 - xOld)/x2) * 100;
            // Guardar resultados
            modelo.addRow(new Object[]{i, x0, x1, x2, fx0, fx1, f.applyAsDouble(x2), ea});
            // Avanzar a los siguientes puntos
            x0 = x1;
            x1 = x2;
            i++;
        }
        iterSecante = i-1;
    }
}

