/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mvc_constancia;

/**
 *
 * @author Sabdiel
 */
public class MVC_Constancia {
    public static void main(String[] args){
        repositorioAlumno repo = new repositorioAlumno();
        vistaConstancia vista = new vistaConstancia();
        controladorConstancia controlador = new controladorConstancia(vista, repo);
        vista.setVisible(true);
    }
}
