/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mvc_constancia;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Sabdiel
 */
public class repositorioAlumno {
    private List<Alumno> alumnos = new ArrayList<>();

    public repositorioAlumno(){
        alumnos.add(new Alumno("00000251925", "Javier Sabdiel Zamudio Corona", "4°", 6));
        alumnos.add(new Alumno("00000252369", "Esther Alicia Félix Gil", "3°", 5));
        alumnos.add(new Alumno("00000231204", "Sally Corona Félix", "2°", 4));
    }

    public List<Alumno> buscarPorIDParcial(String texto){
        List<Alumno> resultado = new ArrayList<>();
        for(Alumno a : alumnos){
            if(a.getId().toLowerCase().contains(texto.toLowerCase())){
                resultado.add(a);
            }
        }
        return resultado;
    }
}
