/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mvc_constancia;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.List;

public class controladorConstancia {
    private vistaConstancia vista;
    private repositorioAlumno repo;
    private List<Alumno> alumnosFiltrados;
    private Alumno alumnoSeleccionado;

    public controladorConstancia(vistaConstancia vista, repositorioAlumno repo){
        this.vista = vista;
        this.repo = repo;

        
        vista.txtID.getDocument().addDocumentListener(new DocumentListener(){
            public void changedUpdate(DocumentEvent e){ actualizarLista(); }
            public void removeUpdate(DocumentEvent e){ actualizarLista(); }
            public void insertUpdate(DocumentEvent e){ actualizarLista(); }
        });

        
        vista.lstAlumno.addListSelectionListener(e -> {
            int idx = vista.lstAlumno.getSelectedIndex();
            if(idx >=0){
                alumnoSeleccionado = alumnosFiltrados.get(idx);
                vista.txtDetalle.setText(alumnoSeleccionado.getDatosConfirmacion());
            }
        });

        
        vista.btnGenCons.addActionListener(e -> {
            if(alumnoSeleccionado != null){
                vista.txtDetalle.setText(alumnoSeleccionado.generarConstancia());
            }
        });
    }

    private void actualizarLista(){
        String texto = vista.txtID.getText();
        alumnosFiltrados = repo.buscarPorIDParcial(texto);
        DefaultListModel<String> model = new DefaultListModel<>();
        for(Alumno a : alumnosFiltrados){
            model.addElement(a.getId()+" - "+a.getNombre());
        }
        vista.lstAlumno.setModel(model);
    }
}