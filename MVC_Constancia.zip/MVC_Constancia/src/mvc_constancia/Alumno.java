/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mvc_constancia;

/**
 *
 * @author Sabdiel
 */
public class Alumno {
     private String id;
    private String nombre;
    private String semestre;
    private int materias;

    public Alumno(String id, String nombre, String semestre, int materias){
        this.id = id;
        this.nombre = nombre;
        this.semestre = semestre;
        this.materias = materias;
    }

    public String getId(){ return id; }
    public String getNombre(){ return nombre; }
    public String getSemestre(){ return semestre; }
    public int getMaterias(){ return materias; }

    public String getDatosConfirmacion(){
        return "ID: "+id+"\nNombre: "+nombre+
               "\nSemestre: "+semestre+"\nMaterias: "+materias;
    }

    public String generarConstancia(){
        return "------ CONSTANCIA ------\n" +
               "Alumno: "+nombre+"\nID: "+id+
               "\nSemestre: "+semestre+"\nMaterias inscritas: "+materias+
               "\n------------------------";
    }
}