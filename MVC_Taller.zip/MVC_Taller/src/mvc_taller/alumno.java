/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mvc_taller;

/**
 *
 * @author Infraestructura
 */
public class alumno {
    private String id;
    private String nombre;
    private String semestre;
    private String programa;

    public alumno(String id, String nombre, String semestre, String programa) {
        this.id = id;
        this.nombre = nombre;
        this.semestre = semestre;
        this.programa = programa;
    }

    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public String getSemestre() { return semestre; }
    public String getPrograma() { return programa; }

    public String getDatos() {
        return "ID: " + id + "\nNombre: " + nombre + 
               "\nSemestre: " + semestre + "\nPrograma: " + programa;
    }

    public String generarTicket(taller taller) {
        return "--- Ticket de inscripción ---\n" + getDatos() +
               "\n\n" + taller.getDetalles() +
               "\nInscripción realizada con éxito.";
    }
}
