/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mvc_taller;

/**
 *
 * @author Infraestructura
 */
public class taller {
    private String nombre;
    private String instructor;
    private String fecha;
    private String horario;

    public taller(String nombre, String instructor, String fecha, String horario) {
        this.nombre = nombre;
        this.instructor = instructor;
        this.fecha = fecha;
        this.horario = horario;
    }

    public String getNombre() { return nombre; }
    public String getInstructor() { return instructor; }
    public String getFecha() { return fecha; }
    public String getHorario() { return horario; }

    public String getDetalles() {
        return "Taller: " + nombre + "\nInstructor: " + instructor +
               "\nFecha: " + fecha + "\nHorario: " + horario;
    }
}
