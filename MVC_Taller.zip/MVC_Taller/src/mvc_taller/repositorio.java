/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mvc_taller;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Infraestructura
 */
public class repositorio {
    public List<taller> talleresDisponibles = new ArrayList<>();
    public List<alumno> alumnos = new ArrayList<>();

    public repositorio() {
        // Datos de ejemplo
        talleresDisponibles.add(new taller("Matemáticas Computacionales", "Ing. Susana Ramírez", "14/10/2025", "10:00-12:00"));
        talleresDisponibles.add(new taller("Programación Java", "Ing. Carlos Ibarra", "15/10/2025", "10:00-12:00"));
        talleresDisponibles.add(new taller("Base de Datos", "ing. Carlos Estrella", "16/10/2025", "12:00-14:00"));

        alumnos.add(new alumno("00000252369", "Alicia Félix", "5", "ISW"));
        alumnos.add(new alumno("00000251925", "Sabdiel Zamudio", "5", "ISW"));
        alumnos.add(new alumno("00000232219", "Juan Perez", "1", "ISW"));
        alumnos.add(new alumno("00000211892", "José Quintana", "7", "ISW"));
        alumnos.add(new alumno("00000242129", "Donají Gil", "1", "ISW"));
        alumnos.add(new alumno("00000221427", "Amada Álvarez", "7", "ISW"));
    }

    public List<alumno> buscarPorIDParcial(String texto) {
        List<alumno> resultado = new ArrayList<>();
        for (alumno a : alumnos) {
            if (a.getId().toLowerCase().contains(texto.toLowerCase())) {
                resultado.add(a);
            }
        }
        return resultado;
    }

    public List<taller> getTallerDis() {
        return talleresDisponibles;
    }
}
