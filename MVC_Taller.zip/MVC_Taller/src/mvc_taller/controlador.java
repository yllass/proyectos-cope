/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mvc_taller;

import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author Infraestructura
 */
public class controlador {
    private vistaTaller vista;
    private repositorio repo;
    private taller tallerSeleccionado;
    private alumno alumnoSeleccionado;
    private List<alumno> alumnosFiltrados;
    
    public controlador(vistaTaller vista, repositorio repo) {
        this.vista = vista;
        this.repo = repo;

        DefaultListModel<String> model = new DefaultListModel<>();
            for (taller t : repo.getTallerDis()) {
                model.addElement(t.getNombre());
            }
        vista.lstTallerDis.setModel(model);

        // Mostrar detalles del taller al seleccionar
        vista.lstTallerDis.addListSelectionListener(e -> {
            int idx = vista.lstTallerDis.getSelectedIndex();
            if(idx >=0) {
                tallerSeleccionado = repo.talleresDisponibles.get(idx);
                vista.txtDetTa.setText(tallerSeleccionado.getDetalles());
            }
        });

        // Filtrar alumnos mientras se escribe ID
        vista.txtID.getDocument().addDocumentListener(new DocumentListener(){
            public void changedUpdate(DocumentEvent e){ actualizarLista(); }
            public void removeUpdate(DocumentEvent e){ actualizarLista(); }
            public void insertUpdate(DocumentEvent e){ actualizarLista(); }
        });

        vista.lstAlumno.addListSelectionListener(e -> {
            int idx = vista.lstAlumno.getSelectedIndex();
            if(idx >=0){
                alumnoSeleccionado = alumnosFiltrados.get(idx);
                vista.txtDatAlumn.setText(alumnoSeleccionado.getDatos());
            }
        });

        // Botón Inscribirse
        vista.btnInscribir.addActionListener(e -> {
            if(tallerSeleccionado != null && alumnoSeleccionado != null){
                vista.txtDatAlumn.setText(alumnoSeleccionado.generarTicket(tallerSeleccionado));
            }
        });
    }

    private void actualizarLista() {
        String texto = vista.txtID.getText();
        alumnosFiltrados = repo.buscarPorIDParcial(texto);
        DefaultListModel<String> model = new DefaultListModel<>();
        for(alumno a : alumnosFiltrados){
            model.addElement(a.getId() + " - " + a.getNombre());
        }
        vista.lstAlumno.setModel(model);
    }
}
